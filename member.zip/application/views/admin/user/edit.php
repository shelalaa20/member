<div class="card shadow-sm border-0">
  <div class="card-header bg-danger text-white">
    <h5 class="mb-0">
      <i class="fas fa-user-edit me-2"></i> Edit User
    </h5>
  </div>

  <div class="card-body">
    <form action="<?= site_url('admin/user/update/'.$user['id']) ?>" method="post" class="row g-3">
      
      <div class="col-md-6">
        <label class="form-label fw-bold">Username</label>
        <input type="text" name="username" class="form-control form-control-sm" 
               value="<?= $user['username'] ?>" required>
      </div>

      <div class="col-md-6">
        <label class="form-label fw-bold">Password <small>(kosongkan jika tidak diubah)</small></label>
        <input type="text" name="password" class="form-control form-control-sm">
      </div>

      <div class="col-md-6">
        <label class="form-label fw-bold">Nama</label>
        <input type="text" name="nama" class="form-control form-control-sm" 
               value="<?= $user['nama'] ?>" required>
      </div>

      <div class="col-md-6">
        <label class="form-label fw-bold">Role</label>
        <select name="role" class="form-select form-select-sm" required>
          <option value="admin" <?= ($user['role']=='admin')?'selected':'' ?>>Admin</option>
          <option value="pelanggan" <?= ($user['role']=='pelanggan')?'selected':'' ?>>Pelanggan</option>
        </select>
      </div>

      <div class="col-12 d-flex justify-content-between mt-3">
        <a href="<?= site_url('admin/user') ?>" class="btn btn-secondary btn-sm">
          <i class="fas fa-arrow-left me-1"></i> Batal
        </a>
        <button type="submit" class="btn btn-success btn-sm">
          <i class="fas fa-save me-1"></i> Update
        </button>
      </div>
    </form>
  </div>
</div>

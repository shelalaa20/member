<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="text-dark mb-0">
    <i class="fas fa-users me-2 text-danger"></i> Daftar Pelanggan
  </h3>
  <a href="<?= site_url('admin/pelanggan/create') ?>" class="btn btn-primary btn-sm shadow-sm">
    <i class="fas fa-user-plus me-1"></i> Tambah
  </a>
</div>

<!-- Form Pencarian -->
<form method="get" action="<?= site_url('admin/pelanggan') ?>" class="mb-3 d-flex">
  <input type="text" 
         name="keyword" 
         class="form-control form-control-sm me-2 border-secondary"
         placeholder="Cari nama / kontak / paket"
         value="<?= html_escape($keyword ?? '') ?>">
  <button type="submit" class="btn btn-dark btn-xs shadow-sm me-2">
    <i class="fas fa-search me-1"></i> Cari
  </button>
  <a href="<?= site_url('admin/pelanggan') ?>" class="btn btn-secondary btn-xs shadow-sm">
    <i class="fas fa-undo me-1"></i> Reset
  </a>
</form>

<!-- Table View untuk Desktop -->
<div class="table-responsive d-none d-md-block">
  <table class="table table-striped align-middle table-hover" style="font-size:0.85rem;">
    <thead class="table-dark text-white" style="font-size:0.8rem;">
      <tr class="text-center">
        <th>ID</th>
        <th>VA</th>
        <th>NAMA</th>
        <th>KONTAK</th>
        <th>PAKET</th>
        <th>KECEPATAN</th>
        <th>JATUH TEMPO</th>
        <th>TGL DAFTAR</th>
        <th>TGL NON AKTIF</th>
        <th>AKSI</th>
      </tr>
    </thead>
    <tbody>
      <?php if(!empty($members)): ?>
        <?php foreach($members as $m): ?>
        <tr class="align-middle">
          <td class="text-center"><?= html_escape($m['id_member']) ?></td>
          <td class="text-center"><?= html_escape($m['va']) ?></td>
          <td><?= html_escape($m['nama']) ?></td>
          <td><?= html_escape($m['kontak']) ?></td>
          <td><?= html_escape($m['nama_paket']) ?></td>
          <td><?= html_escape($m['kecepatan']) ?></td>
          <td><?= html_escape($m['jatuh_tempo']) ?></td>
          <td><?= html_escape($m['tanggal_daftar']) ?></td>
          <td><?= html_escape($m['tanggal_non_aktif']) ?></td>
          <td class="text-center">
            <a href="<?= site_url('admin/pelanggan/edit/'.$m['id_member']) ?>" class="btn btn-warning btn-sm me-1 text-dark shadow-sm">
              <i class="fas fa-edit"></i>
            </a>
            <a href="<?= site_url('admin/pelanggan/delete/'.$m['id_member']) ?>" 
               class="btn btn-danger btn-sm shadow-sm"
               onclick="return confirm('Yakin hapus?')">
              <i class="fas fa-trash-alt"></i>
            </a>
          </td>
        </tr>
        <?php endforeach ?>
      <?php else: ?>
        <tr>
          <td colspan="10" class="text-center text-muted py-2">Tidak ada data pelanggan</td>
        </tr>
      <?php endif ?>
    </tbody>
  </table>
  <!-- Pagination -->
  <div>
    <?= $pagination ?>
  </div>
</div>
<div class="d-block d-md-none">
  <?php if(!empty($members)): ?>
    <?php foreach($members as $m): ?>
      <div class="card mb-3 shadow-sm border-0 rounded-3">
        <div class="card-body p-3">
          <!-- Header: Nama + ID + VA -->
          <div class="d-flex justify-content-between align-items-start mb-2">
            <div>
              <h6 class="card-title mb-1 fw-bold"><?= html_escape($m['nama']) ?></h6>
              <small class="text-muted">ID: <?= html_escape($m['id_member']) ?></small>
            </div>
            <span class="badge bg-primary"><?= html_escape($m['va']) ?></span>
          </div>

          <!-- Info Detail -->
          <ul class="list-unstyled mb-2">
            <li><strong>Kontak:</strong> <?= html_escape($m['kontak']) ?></li>
            <li><strong>Paket:</strong> <?= html_escape($m['nama_paket']) ?></li>
            <li><strong>Kecepatan:</strong> <?= html_escape($m['kecepatan']) ?></li>
            <li><strong>Jatuh Tempo:</strong> <span class="text-danger fw-semibold"><?= html_escape($m['jatuh_tempo']) ?></span></li>
            <li><strong>Tgl Daftar:</strong> <?= html_escape($m['tanggal_daftar']) ?></li>
            <li><strong>Tgl Non Aktif:</strong> <?= html_escape($m['tanggal_non_aktif']) ?></li>
          </ul>

          <!-- Action Button -->
          <div class="d-flex justify-content-end mt-2 gap-2">
            <a href="<?= site_url('admin/pelanggan/edit/'.$m['id_member']) ?>" 
               class="btn btn-warning btn-sm text-dark shadow-sm">
              <i class="fas fa-edit me-1"></i> Edit
            </a>
            <a href="<?= site_url('admin/pelanggan/delete/'.$m['id_member']) ?>" 
               class="btn btn-danger btn-sm shadow-sm"
               onclick="return confirm('Yakin hapus?')">
              <i class="fas fa-trash-alt me-1"></i> Hapus
            </a>
          </div>
        </div>
      </div>
    <?php endforeach ?>
  <?php else: ?>
    <p class="text-center text-muted mt-3">Tidak ada data pelanggan</p>
  <?php endif ?>
</div>
<!-- Pagination untuk Mobile -->
<?php if(!empty($members) && isset($pagination)): ?>
  <div class="mt-2 d-flex justify-content-center">
    <?= $pagination ?>
  </div>
<?php endif; ?>






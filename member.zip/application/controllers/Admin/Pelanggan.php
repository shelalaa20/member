<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pelanggan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('MemberModel');
        $this->load->library('pagination');
    }

// List pelanggan
public function index()
{
    $this->load->library('pagination');

    $keyword = $this->input->get('keyword');

    // Pagination setup
    $config['base_url']    = site_url('admin/pelanggan/index');
    $config['total_rows']  = $this->MemberModel->countAll($keyword);
    $config['per_page']    = 25;
    $config['uri_segment'] = 4;

    // Styling Bootstrap
    $config['full_tag_open']   = '<ul class="pagination">';
    $config['full_tag_close']  = '</ul>';
    $config['first_link']      = 'First';
    $config['last_link']       = 'Last';
    $config['first_tag_open']  = '<li class="page-item"><span class="page-link">';
    $config['first_tag_close'] = '</span></li>';
    $config['last_tag_open']   = '<li class="page-item"><span class="page-link">';
    $config['last_tag_close']  = '</span></li>';
    $config['next_link']       = '&raquo;';
    $config['next_tag_open']   = '<li class="page-item"><span class="page-link">';
    $config['next_tag_close']  = '</span></li>';
    $config['prev_link']       = '&laquo;';
    $config['prev_tag_open']   = '<li class="page-item"><span class="page-link">';
    $config['prev_tag_close']  = '</span></li>';
    $config['cur_tag_open']    = '<li class="page-item active"><span class="page-link">';
    $config['cur_tag_close']   = '</span></li>';
    $config['num_tag_open']    = '<li class="page-item"><span class="page-link">';
    $config['num_tag_close']   = '</span></li>';

    $this->pagination->initialize($config);

    // Pastikan segment angka, kalau null fallback ke 0
    $page = $this->uri->segment(4);
    $page = (ctype_digit((string) $page)) ? (int)$page : 0;
    
    $data['members']     = $this->MemberModel->getPaginated($config['per_page'], $page, $keyword);
    $data['pagination']  = $this->pagination->create_links();
    $data['keyword']     = $keyword;

    // Tampilkan dengan layout_admin
    $data['content'] = $this->load->view('admin/pelanggan/index', $data, TRUE);
    $this->load->view('layout_admin', $data);
}


    // Form tambah
    public function create()
    {
        $data['content'] = $this->load->view('admin/pelanggan/create', [], TRUE);
        $this->load->view('layout_admin', $data);
    }

    // Simpan pelanggan baru
    public function store()
    {
        $data = $this->input->post();

        // Validasi wajib
        $requiredFields = ['id_member','nama','kontak','nama_paket','kecepatan','jatuh_tempo','tanggal_daftar','va'];
        foreach ($requiredFields as $field) {
            if (empty($data[$field])) {
                $this->session->set_flashdata('error', "Field wajib belum diisi: $field");
                redirect('admin/pelanggan/create');
            }
        }

        // Cek duplikat ID member
        if ($this->MemberModel->findBy('id_member', $data['id_member'])) {
            $this->session->set_flashdata('error', "ID member '{$data['id_member']}' sudah terdaftar. Gunakan ID lain.");
            redirect('admin/pelanggan/create');
        }

        // Cek duplikat VA
        if ($this->MemberModel->findBy('va', $data['va'])) {
            $this->session->set_flashdata('error', "VA '{$data['va']}' sudah terdaftar. Gunakan VA lain.");
            redirect('admin/pelanggan/create');
        }

        // Insert data
        $this->MemberModel->insertData($data);
        $this->session->set_flashdata('success', 'Pelanggan berhasil ditambahkan!');
        redirect('admin/pelanggan');
    }

    // Form edit
    public function edit($id_member)
    {
        $data['member'] = $this->MemberModel->find($id_member);
        $data['content'] = $this->load->view('admin/pelanggan/edit', $data, TRUE);
        $this->load->view('layout_admin', $data);
    }

    // Update data
    public function update($id_member)
    {
        $updateData = $this->input->post();
        $this->MemberModel->updateData($id_member, $updateData);
        $this->session->set_flashdata('success', 'Pelanggan berhasil diperbarui!');
        redirect('admin/pelanggan');
    }

    // Hapus data
    public function delete($id_member)
    {
        $this->MemberModel->deleteData($id_member);
        $this->session->set_flashdata('success', 'Pelanggan berhasil dihapus!');
        redirect('admin/pelanggan');
    }
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserModel extends CI_Model {

    protected $table = 'users';

    // Ambil semua user dengan filter + keyword + limit untuk pagination
    public function getUsers($keyword = null, $role = null, $limit = null, $start = null)
    {
        if ($keyword) {
            $this->db->group_start();
            $this->db->like('username', $keyword);
            $this->db->or_like('nama', $keyword);
            $this->db->group_end();
        }

        if ($role && $role != 'all') {
            $this->db->where('role', $role);
        }

        if ($limit) {
            $this->db->limit($limit, $start);
        }

        return $this->db->get($this->table)->result_array();
    }

    public function countUsers($keyword = null, $role = null)
    {
        if ($keyword) {
            $this->db->group_start();
            $this->db->like('username', $keyword);
            $this->db->or_like('nama', $keyword);
            $this->db->group_end();
        }

        if ($role && $role != 'all') {
            $this->db->where('role', $role);
        }

        return $this->db->count_all_results($this->table);
    }

    public function getById($id)
    {
        return $this->db->get_where($this->table, ['id' => $id])->row_array();
    }

    public function insertUser($data)
    {
        return $this->db->insert($this->table, $data);
    }

    public function updateUser($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update($this->table, $data);
    }

    public function deleteUser($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete($this->table);
    }

    // ==========================
    // Tambahan untuk login CI3 agar mirip CI4
    // ==========================
    public function getUserBy($field, $value)
    {
        return $this->db->get_where($this->table, [$field => $value])->row_array();
    }

        // Update password
        public function updatePassword($id, $newPassword)
        {
            return $this->db->where('id', $id)
                            ->update($this->table, ['password' => $newPassword]);
        }
}
